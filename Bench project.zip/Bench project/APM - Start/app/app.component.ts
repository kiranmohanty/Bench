import { Component } from '@angular/core';


@Component({
    selector: 'pm-app',
    template:`<h3> {{pageTitle}} </h3>
             <bench-employee></bench-employee>`
})
export class AppComponent {
   pageTitle:string ="Tavant Bench";
   
 }
