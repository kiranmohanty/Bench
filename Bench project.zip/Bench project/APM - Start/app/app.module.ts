import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { AppComponent }  from './app.component';
import {BenchEmployeeComponent} from './bench/bench-employee-list.component';
import {EmployeePipe,ExperiencePipe} from './bench/employee-pipes.pipe';


@NgModule({
  imports: [ BrowserModule ,FormsModule],
  declarations: [ AppComponent,BenchEmployeeComponent,EmployeePipe ,ExperiencePipe],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
