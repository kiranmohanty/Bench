export class employee{
        id:number;
        name:string;
        designation : string;
        skill:string;
        YOE: number;
        timeOnBench: number;
        trained:string;
        image:string

        constructor(id:number, name:string, designation : string, skill:string, YOE: number, timeOnBench: number,trained:string,image:string)
        {
            this.id=id;
            this.name=name;
            this.designation=designation;
            this.skill=skill;
            this.YOE=YOE;
            this.timeOnBench=timeOnBench;
            this.trained=trained;
            this.image=image;
        }
}

export const employeeList: employee[]=
[
       new employee(1,"Kali Prasad","Software Engineer","java,MVC",4.75,4,"angular 2.0","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(2,"Madhan","Senior Software Engineer",".NET, Angular",7,1,"angular 2.0,MVC","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(3,"Saswat","Senior Software Engineer","Big Data",3,2,"sparks","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(4,"Lakshmi","Senior Software Engineer","java,HTML",3,0,"java","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(5,"Sachin","Software Engineer",".Net, Angular",3,2,"angular 2.0","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(6,"Santosh","Senior Software Engineer",".NET,MVC, Web API",4,1,"","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(7,"Kiran","Software Engineer",".net,MVC",2.5,2,"angular 2.0","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png"),
       new employee(8,"Aparesh","Tech. Lead",".NET,MVC,Angular JS",10.05,0,"angular 2.0","https://www.nbrii.com/wp-content/uploads/2011/02/employee-attitude-surveys.png")
]
