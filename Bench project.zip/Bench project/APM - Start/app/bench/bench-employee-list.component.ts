import {Component} from '@angular/core';

import {employeeList, employee} from './employee';

@Component({
    selector: 'bench-employee',
    templateUrl:'app/bench/bench-employee-list.component.html'
})

export class BenchEmployeeComponent{
    //properties
      panelHeading:string='Employee List';
      employees: employee[]=employeeList;
      seachBySkill: string ='';
      seachByDesignation:string ='';
      seachByExperience:string =''; 
      showImage:boolean=false; 
      decimalPrecision :string='1.0-1'; 

    //methods
      toggleImage():void{
          this.showImage=!this.showImage;
      }   
}