import {Pipe, PipeTransform} from '@angular/core';
import {employee} from './employee';

@Pipe({
    name: 'empFilter'
})
export class EmployeePipe implements PipeTransform {
    // value is the actual list of data, exponent is filter condition
   transform(value:employee[], exponent:string, field:string){                   
        if(exponent && exponent.length>0 && value && value.length>0){
             var data:string=''; 
             var filteredData: employee[]=[];


            value.forEach(element => {
                if(field=='skill'){
                    data=element.skill;
                }
                else {
                    data=element.designation;
                }                

                if(data.toLocaleLowerCase().indexOf(exponent.toLowerCase())>-1){
                    filteredData.push( element);
                }
            });
             return filteredData;
        }
        else{
            return value;
        }
   }
}

@Pipe({ name: 'experienceFilter' })
export class ExperiencePipe implements PipeTransform {
    transform(value: employee[], pipeCondition: string, decimalPrecision:string) {
        var yearOfExp: number = parseFloat(pipeCondition.replace(/[^0-9\.]+/g,''));

        if (pipeCondition && pipeCondition.length > 0 && value && value.length > 0 && yearOfExp) {
            var data: number = 0;            
            var filteredData: employee[] = [];
            var maxDecimalFigure:number=parseInt(decimalPrecision.substring(decimalPrecision.indexOf('-')+1)); //ex 1.0-1 => o/p->1


            value.forEach(element => {
                //rounding off decimal figure
                data= parseFloat( element.YOE.toFixed(maxDecimalFigure));

                if (pipeCondition.indexOf('>=') > -1) {
                    if ( data >= yearOfExp) {
                        filteredData.push(element);
                    }
                }
                else if (pipeCondition.indexOf('<=') > -1) {
                    if (data <= yearOfExp) {
                        filteredData.push(element);
                    }
                }
               else if (pipeCondition.indexOf('>') > -1) {
                    if (data > yearOfExp) {
                        filteredData.push(element);
                    }
                }
                else if (pipeCondition.indexOf('<') > -1) {
                    if (data < yearOfExp) {
                        filteredData.push(element);
                    }
                }                
                else {
                    if (data == yearOfExp) {
                        filteredData.push(element);
                    }
                }
            });
            return filteredData;
        }
        else{
            return value;
        }
    }
}

