"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var EmployeePipe = (function () {
    function EmployeePipe() {
    }
    // value is the actual list of data, exponent is filter condition
    EmployeePipe.prototype.transform = function (value, exponent, field) {
        if (exponent && exponent.length > 0 && value && value.length > 0) {
            var data = '';
            var filteredData = [];
            value.forEach(function (element) {
                if (field == 'skill') {
                    data = element.skill;
                }
                else {
                    data = element.designation;
                }
                if (data.toLocaleLowerCase().indexOf(exponent.toLowerCase()) > -1) {
                    filteredData.push(element);
                }
            });
            return filteredData;
        }
        else {
            return value;
        }
    };
    return EmployeePipe;
}());
EmployeePipe = __decorate([
    core_1.Pipe({
        name: 'empFilter'
    }),
    __metadata("design:paramtypes", [])
], EmployeePipe);
exports.EmployeePipe = EmployeePipe;
var ExperiencePipe = (function () {
    function ExperiencePipe() {
    }
    ExperiencePipe.prototype.transform = function (value, pipeCondition, decimalPrecision) {
        var yearOfExp = parseFloat(pipeCondition.replace(/[^0-9\.]+/g, ''));
        if (pipeCondition && pipeCondition.length > 0 && value && value.length > 0 && yearOfExp) {
            var data = 0;
            var filteredData = [];
            var maxDecimalFigure = parseInt(decimalPrecision.substring(decimalPrecision.indexOf('-') + 1)); //ex 1.0-1 => o/p->1
            value.forEach(function (element) {
                //rounding off decimal figure
                data = parseFloat(element.YOE.toFixed(maxDecimalFigure));
                if (pipeCondition.indexOf('>=') > -1) {
                    if (data >= yearOfExp) {
                        filteredData.push(element);
                    }
                }
                else if (pipeCondition.indexOf('<=') > -1) {
                    if (data <= yearOfExp) {
                        filteredData.push(element);
                    }
                }
                else if (pipeCondition.indexOf('>') > -1) {
                    if (data > yearOfExp) {
                        filteredData.push(element);
                    }
                }
                else if (pipeCondition.indexOf('<') > -1) {
                    if (data < yearOfExp) {
                        filteredData.push(element);
                    }
                }
                else {
                    if (data == yearOfExp) {
                        filteredData.push(element);
                    }
                }
            });
            return filteredData;
        }
        else {
            return value;
        }
    };
    return ExperiencePipe;
}());
ExperiencePipe = __decorate([
    core_1.Pipe({ name: 'experienceFilter' }),
    __metadata("design:paramtypes", [])
], ExperiencePipe);
exports.ExperiencePipe = ExperiencePipe;
//# sourceMappingURL=employee-pipes.pipe.js.map